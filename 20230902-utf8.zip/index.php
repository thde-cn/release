<?php
version_compare(PHP_VERSION, '5.4.0', '<') and exit('PHP 5.4+ is required');
require __DIR__.'/server/library/param.php';
require __DIR__.'/server/library/base.php';
require __DIR__.'/server/library/guide.php';
?>