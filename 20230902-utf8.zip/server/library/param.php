<?php
$param = [
	'basic' => ['title' => '欢乐斗地主', 'keywords' => 'h5网页游戏,扑克,纸牌', 'description' => '无需下载，点开就可以直接玩的斗地主', 'icp' => '', 'stat' => '', 'power' => '1', 'notice' => '本站正在维护，给您带来的不便敬请谅解！'],
	'cache' => ['cache_power' => '0', 'cache_expire' => '3600'],
	'game' => ['game_cost' => '1', 'game_small_base' => '1', 'game_medium_base' => '10', 'game_high_base' => '100', 'game_big_base' => '1000'],
	'mail' => ['mail_power' => '0', 'mail_port' => '', 'mail_host' => '', 'mail_user' => '', 'mail_pw' => ''],
	'shield' => ['shield_login_try' => '3', 'shield_login_catch' => '15', 'shield_reg_try' => '3', 'shield_reg_catch' => '15', 'shield_mail_try' => '3', 'shield_mail_catch' => '15']
];
?>